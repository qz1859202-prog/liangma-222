// An interactive prelude. The line end is a real, keyboard-accessible button.
const root=document.documentElement,body=document.body,reduced=matchMedia('(prefers-reduced-motion: reduce)');
let layer=null,frame=0,phase='waiting',started=0,w=0,h=0,canvas,ctx,curves=[],target={x:0,y:0},resolving=false,lastTime=0,waitingTick=0,headHeld=false,waitingClock=0;
const ease=t=>1-Math.pow(1-Math.max(0,Math.min(1,t)),3),mix=(a,b,t)=>a+(b-a)*t;
let seed=222;const random=()=>{seed=(seed*16807)%2147483647;return (seed-1)/2147483646;};
function setInert(value){document.querySelector('.site-header').inert=value;document.querySelector('.cover').inert=value;document.querySelector('#window-stack').inert=value;}
function makeCurves(){
 seed=222;curves=[];
 // Occupy the viewport field, with only a small header/footer safety margin.
 const left=Math.max(18,w*.02),right=w-left,top=Math.max(82,h*.085),bottom=h-Math.max(88,h*.09);
 const rangeX=right-left,rangeY=Math.max(160,bottom-top),cx=(left+right)/2,cy=(top+bottom)/2,count=64;
 for(let i=0;i<count;i++){
  const points=Array.from({length:4},()=>({x:left+random()*rangeX,y:top+random()*rangeY}));
  // Distribute endpoints around the outer field as well as through its interior.
  if(i<24){const edge=i%4;if(edge===0)points[0].x=left+random()*12;if(edge===1)points[0].x=right-random()*12;if(edge===2)points[0].y=top+random()*12;if(edge===3)points[0].y=bottom-random()*12;}
  curves.push({points,alpha:.18+random()*.65,angle:i/count*Math.PI*2+(random()-.5)*.2,delay:random()*.12});
 }
 target={x:left+rangeX*.78,y:top+rangeY*.59};curves[0].points[3]=target;
}
function livingPoints(curve,i,now){
 const t=reduced.matches?0:(now-waitingClock)/1000,amplitude=Math.min(w*.022,23);
 const controls=curve.points.map((p,j)=>({x:p.x+Math.sin(t*.63+i*1.4+j*1.8)*(j===0||j===3?5:amplitude),y:p.y+Math.cos(t*.49+i*.8+j*2.3)*(j===0||j===3?5:amplitude*1.1)}));
 if(i===0&&headHeld)controls[3]={...curve.points[3]};
 return Array.from({length:37},(_,k)=>{const u=k/36,v=1-u,a=controls[0],b=controls[1],c=controls[2],d=controls[3];
  const x=v*v*v*a.x+3*v*v*u*b.x+3*v*u*u*c.x+u*u*u*d.x,y=v*v*v*a.y+3*v*v*u*b.y+3*v*u*u*c.y+u*u*u*d.y;
  const dx=3*v*v*(b.x-a.x)+6*v*u*(c.x-b.x)+3*u*u*(d.x-c.x),dy=3*v*v*(b.y-a.y)+6*v*u*(c.y-b.y)+3*u*u*(d.y-c.y),length=Math.hypot(dx,dy)||1;
  const wave=reduced.matches?0:Math.sin(Math.PI*u)*(Math.sin(u*12-t*1.6+i*1.7)*11+Math.sin(u*21+t*.95+i)*5);
  return {x:x-dy/length*wave,y:y+dx/length*wave};
 });
}
function size(){if(!layer)return;w=innerWidth;h=innerHeight;const dpr=Math.min(devicePixelRatio||1,1.5);canvas.width=w*dpr;canvas.height=h*dpr;ctx.setTransform(dpr,0,0,dpr,0,0);makeCurves();const end=layer.querySelector('.thread-end');end.style.left=target.x+'px';end.style.top=target.y+'px';if(phase==='waiting'){cancelAnimationFrame(frame);waitingTick=0;paint(performance.now());}}
function paint(now){frame=0;if(!layer||document.hidden)return;if(phase==='waiting'&&!reduced.matches&&now-waitingTick<30){frame=requestAnimationFrame(paint);return;}waitingTick=now;ctx.clearRect(0,0,w,h);const cx=w*.5,cy=h*.5,elapsed=(now-started)/1000;
 curves.forEach((curve,i)=>{let points,alpha=curve.alpha;const original=curve.frozen||curve.points;let sampled=false;
 if(phase==='waiting'){points=livingPoints(curve,i,now);sampled=true;alpha*=.78+.22*Math.sin((now-waitingClock)/1800+i);if(i===0){const end=layer.querySelector('.thread-end'),tip=points.at(-1);end.style.left=tip.x+'px';end.style.top=tip.y+'px';}}
 else if(elapsed<.94){const p=ease((elapsed-curve.delay)/.78);points=original.map(v=>({x:mix(v.x,cx,p),y:mix(v.y,cy,p)}));alpha*=1-p*.65;sampled=!!curve.frozen;}
 else if(elapsed<1.16)return;
 else{
  const burst=ease((elapsed-1.16)/.43),retract=ease((elapsed-1.91)/.64),angle=curve.angle;
  const radius=Math.hypot(w,h)*.66;const endRadius=radius*burst*(1-retract*.76);
  const ex=cx+Math.cos(angle)*endRadius,ey=cy+Math.sin(angle)*endRadius;
  const bend=Math.sin(angle*3)*retract*50;
  points=[{x:cx,y:cy},{x:mix(cx,ex,.34)+bend,y:mix(cy,ey,.34)-bend},{x:mix(cx,ex,.68)+bend,y:mix(cy,ey,.68)-bend},{x:ex,y:ey}];alpha*=1-retract*.5;
 }
 ctx.beginPath();ctx.moveTo(points[0].x,points[0].y);if(sampled)points.slice(1).forEach(p=>ctx.lineTo(p.x,p.y));else ctx.bezierCurveTo(points[1].x,points[1].y,points[2].x,points[2].y,points[3].x,points[3].y);ctx.strokeStyle=`rgba(239,238,233,${alpha})`;ctx.lineWidth=i%5===0?1:.65;ctx.stroke();
 });
 if(phase==='running'){
  if(elapsed>2.18&&!resolving){resolving=true;body.classList.add('intro-resolving');layer.classList.add('is-resolving');}
  if(elapsed>3.05){finish();return;}
  if(!document.hidden)frame=requestAnimationFrame(paint);
 }else if(!reduced.matches&&!document.hidden)frame=requestAnimationFrame(paint);
}
function finish(){if(!layer)return;cancelAnimationFrame(frame);const old=layer;layer=null;old.remove();body.classList.remove('intro-pending','intro-running','intro-resolving');setInert(false);phase='waiting';resolving=false;document.querySelector('[data-work]')?.focus({preventScroll:true});}
function begin(){if(phase==='running')return;if(reduced.matches){finish();return;}cancelAnimationFrame(frame);const now=performance.now();curves.forEach((curve,i)=>curve.frozen=livingPoints(curve,i,now));phase='running';started=now;body.classList.add('intro-running');layer.classList.add('is-running');layer.querySelector('.thread-end').disabled=true;layer.querySelector('.intro-status').textContent='让一个线头，打开所有可能。';frame=requestAnimationFrame(paint);}
export function showIntro(){if(layer)return;if(document.querySelector('.window'))return;body.classList.add('intro-pending');setInert(true);phase='waiting';resolving=false;headHeld=false;waitingClock=performance.now();
 layer=document.createElement('section');layer.className='thread-intro';layer.setAttribute('role','dialog');layer.setAttribute('aria-modal','true');layer.setAttribute('aria-label','222开场：点击线头展开影像图谱');
 layer.innerHTML='<canvas aria-hidden="true"></canvas><div class="intro-top"><span>量孖 / LIANGMA <small>222 — BEFORE THE IMAGE</small></span><button class="intro-skip">跳过开场 ↗</button></div><button class="thread-end" aria-label="点击闪烁箭头指向的线头，展开图谱"><span class="end-arrow" aria-hidden="true">↓</span><span class="end-hit" aria-hidden="true"></span><span class="end-label">从这个线头开始</span></button><div class="intro-bottom"><span class="intro-status" role="status">万千可能，藏在一个线头里。</span><small>FIND THE END. FOLLOW THE POSSIBILITY.</small></div>';
 body.append(layer);canvas=layer.querySelector('canvas');ctx=canvas.getContext('2d',{alpha:true});if(!ctx){finish();return;}layer.querySelector('.thread-end').onclick=begin;layer.querySelector('.thread-end').onpointerenter=()=>headHeld=true;layer.querySelector('.thread-end').onpointerleave=()=>headHeld=false;layer.querySelector('.intro-skip').onclick=finish;
 layer.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();finish();}if(e.key==='Tab'){const buttons=[...layer.querySelectorAll('button:not(:disabled)')];if(buttons.length===1){e.preventDefault();buttons[0].focus();}else if(e.shiftKey&&document.activeElement===buttons[0]){e.preventDefault();buttons.at(-1).focus();}else if(!e.shiftKey&&document.activeElement===buttons.at(-1)){e.preventDefault();buttons[0].focus();}}});
 size();layer.querySelector('.thread-end').focus({preventScroll:true});
}
window.addEventListener('resize',size,{passive:true});document.addEventListener('visibilitychange',()=>{if(!layer)return;if(document.hidden){cancelAnimationFrame(frame);lastTime=performance.now();}else{const pause=performance.now()-lastTime;started+=pause;waitingClock+=pause;frame=requestAnimationFrame(paint);}});reduced.addEventListener('change',()=>{if(!layer)return;if(phase==='running'&&reduced.matches)finish();else{cancelAnimationFrame(frame);paint(performance.now());}});
document.querySelector('[data-replay-intro]').addEventListener('click',showIntro);
if(!location.hash)showIntro();else body.classList.remove('intro-pending');
