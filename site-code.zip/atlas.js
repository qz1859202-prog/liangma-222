import {works} from './collection.js';
const atlas=document.querySelector('#living-atlas'),cards=document.querySelector('#atlas-works'),lines=document.querySelector('#thread-lines');
const escape=s=>s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
// Coordinates are designed as a constellation, rather than a card grid.
const desktop=[{x:305,y:95,w:172},{x:555,y:70,w:155},{x:810,y:160,w:165},{x:815,y:385,w:181},{x:740,y:590,w:165},{x:470,y:610,w:160},{x:225,y:555,w:155},{x:130,y:345,w:115},{x:190,y:245,w:145},{x:520,y:420,w:150}];
cards.innerHTML=works.map((w,i)=>`<button class="atlas-work ${w.isPortrait?'portrait-work':''}" data-work="${w.id}" aria-label="打开作品：${escape(w.zh)}" style="--order:${i}"><span class="atlas-work-id">LM.${w.number} / ${w.durationLabel}</span><span class="atlas-frame"><img src="${w.poster}" alt="${escape(w.zh)}作品封面" draggable="false" ${i<4?'fetchpriority="high"':'loading="lazy"'}><span class="selection-corners" aria-hidden="true"></span><span class="atlas-open" aria-hidden="true">↗</span></span><span class="atlas-work-name">${escape(w.zh)}</span></button>`).join('');
lines.innerHTML=works.map((w,i)=>`<g data-thread="${i}"><path/><path/><circle r="2"/></g>`).join('');
const nodes=[...cards.children],threads=[...lines.children],reduced=matchMedia('(prefers-reduced-motion: reduce)');
let small=innerWidth<650,frame=0,start=performance.now(),visible=true,last=0;
const positions=()=>small?works.map((_,i)=>({x:i%2?740:260,y:105+Math.floor(i/2)*195,w:350})):desktop;
function draw(now){
 frame=0;if(!visible||document.hidden)return;
 // 30 fps is sufficient for this deliberately slow drift; no decoded videos on the map.
 if(now-last<30&&!reduced.matches){frame=requestAnimationFrame(draw);return;}last=now;
 const t=reduced.matches?0:(now-start)/1000,H=small?1000:700,origin={x:small?500:510,y:small?500:330},p=positions();
 p.forEach((point,i)=>{
  const phase=i*1.71,drift=reduced.matches?0:1;
  const x=point.x+Math.sin(t*.31+phase)*(small?6:9)*drift,y=point.y+Math.cos(t*.25+phase)*(small?5:8)*drift;
  const node=nodes[i];node.style.left=x/10+'%';node.style.top=y/H*100+'%';node.style.width=point.w/10+'%';
  node.style.setProperty('--tilt',Math.sin(t*.19+phase)*.65*drift+'deg');
  const [a,b]=threads[i].querySelectorAll('path'),dot=threads[i].querySelector('circle');
  const dx=x-origin.x,dy=y-origin.y,swirl=small?.12:.4;
  a.setAttribute('d',`M ${origin.x} ${origin.y} C ${origin.x+dy*swirl} ${origin.y-dx*swirl}, ${x-dx*.18+dy*.25} ${y-dy*.28-dx*.15}, ${x} ${y}`);
  b.setAttribute('d',`M ${origin.x+3} ${origin.y+2} C ${origin.x+dy*(swirl+.04)} ${origin.y-dx*(swirl+.04)}, ${x-dx*.13+dy*.27} ${y-dy*.24-dx*.18}, ${x+4} ${y+3}`);
  dot.setAttribute('cx',x);dot.setAttribute('cy',y);
 });
 if(!reduced.matches)frame=requestAnimationFrame(draw);
}
function restart(){cancelAnimationFrame(frame);last=0;if(visible&&!document.hidden)frame=requestAnimationFrame(draw);}
function size(){small=innerWidth<650;atlas.querySelector('svg').setAttribute('viewBox',`0 0 1000 ${small?1000:700}`);restart();}
let frontOrder=60;
nodes.forEach((node,i)=>{const select=on=>{node.classList.toggle('is-selected',on);node.style.zIndex=on?String(++frontOrder):'';threads[i].classList.toggle('is-selected',on);};node.addEventListener('pointerenter',()=>select(true));node.addEventListener('pointerleave',()=>select(false));node.addEventListener('focus',()=>select(true));node.addEventListener('blur',()=>select(false));});
const observer=new IntersectionObserver(([e])=>{visible=e.isIntersecting;restart();});observer.observe(atlas);
window.addEventListener('resize',size,{passive:true});document.addEventListener('visibilitychange',restart);reduced.addEventListener('change',restart);size();
